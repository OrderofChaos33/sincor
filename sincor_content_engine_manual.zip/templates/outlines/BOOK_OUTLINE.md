# Book Outline (200–2000 pages)
- Foreword, Credibility, Promise
- Pillars (10–20): deep dives, SOPs, case studies
- Cluster articles per pillar (5–15 each)
- Local SEO pages (per city/niche)
- Appendices: Glossary, FAQs, Checklist index
