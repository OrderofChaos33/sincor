# Media Kit Outline
- Brand One-Pager
- Offers & Guarantees
- Testimonials & Case Studies
- Flyer Set (A/B/C variants)
- Adset Matrix (Google/Meta)
- Script Pack (15/30/60s)
