# Adset Prompt
Produce 10 headlines (30 chars), 5 desc (90 chars), 3 callouts.
Rotate tone variants; include local signals.
