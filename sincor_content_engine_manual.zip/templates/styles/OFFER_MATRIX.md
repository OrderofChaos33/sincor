# Offer Matrix
- Starter: low-cost intro + guarantee
- Growth: bundle + bonus
- Pro: premium with priority support
