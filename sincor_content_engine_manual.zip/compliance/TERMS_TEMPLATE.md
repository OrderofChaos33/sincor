# Terms (Template)
- No guarantee of results
- Refund/redo policy
- Content usage rights
- Data handling & privacy
