# Daily Ops
- Verify assets inbox (new photos/videos/testimonials).
- Run minimal 50–200 page update if new offers launched.
- Validate URLs, phone, business hours.
- Log run metadata to outputs/runlogs/.
