# Troubleshooting
- Export crash → try MD/DOCX fallback, then re-render PDF.
- Repetition → increase template diversity, adjust weights.
- Thin content → enforce min info density per page.
- Broken links → run link/asset validator; fix relative roots.
