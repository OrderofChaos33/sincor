# Weekly Ops
- Full 200–600 page refresh across all modules.
- Rotate tone variants; update CTA/offer matrix.
- Publish 2–4 pillar posts + clusters.
- Export 3 flyer variants; test 2 adsets per network.
