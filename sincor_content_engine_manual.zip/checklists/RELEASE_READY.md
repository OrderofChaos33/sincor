# Release-Ready Gate
- ✅ QA pass (readability, claims, brand consistency)
- ✅ Dedupe rate < 5% near-duplicate segments
- ✅ Exported: PDF, MD, DOCX
- ✅ Metadata embedded (seed, config hash)
- ✅ Compliance headers inserted
