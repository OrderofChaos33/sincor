# QA Release Checklist
- Headings H2/H3 consistent
- TOC auto-generated and functional
- Stats/facts linked or footnoted
- Testimonials properly attributed
- CTA visible every 2–3 sections (public docs)
- Internal docs free of PII
