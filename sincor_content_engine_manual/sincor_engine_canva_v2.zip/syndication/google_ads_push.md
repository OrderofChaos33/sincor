# Google Ads Push (syndication/google_ads_push.md)
- Generate RSA rows (headlines max 30 chars; descriptions max 90).
- Use Sheets/CSV bulk import or API.
- Tag creatives with run_id for telemetry linkage.
