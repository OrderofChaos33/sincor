# Meta Ads Push (syndication/meta_ads_push.md)
- Upload creatives exported from Canva; name them with run_id + cta_id.
- Create or update campaigns/adsets; attach creatives and copy variants.
- Respect policy; avoid restricted claims; ensure final URLs are correct.
