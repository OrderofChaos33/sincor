# WordPress Push (syndication/wordpress_push.md)
- Prepare post payloads (title, content HTML/MD, featured media).
- Map pillar/cluster content to categories/tags.
- Schedule or publish immediately.
- Store wp_post_id and URL in telemetry for back-pressure learning.
