# Daily Ops
- Ingest new assets (photos, vids, testimonials, offers).
- Run partial cycle; publish 1–2 polished social sets.
- Check telemetry heartbeat; fix any schema breaks.
