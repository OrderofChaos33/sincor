# Weekly Ops
- Rotate tones; refresh CTA phrasing.
- Ship 2 pillar clusters + 3 flyer variants.
- Review dashboards; pivot toward winners.
