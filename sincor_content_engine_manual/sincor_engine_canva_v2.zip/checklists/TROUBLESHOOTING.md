# Troubleshooting
- Repetition → widen tone/style entropy; add synonyms set.
- Thin content → enforce evidence minimums (testimonial/stat/SOP).
- Export breaks → use MD/DOCX fallback; re-render PDF later.
- Low CTR → change template family, headline archetype, or offer tier.
