# Release Gate
- ✅ Q ≥ threshold on all public units
- ✅ Dedupe < 5%
- ✅ Canva exports present and linked
- ✅ Compliance headers inserted
- ✅ Telemetry events emitted
